﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }
        private Form activeForm = null;
        private void openChildForm(Form chilForm)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = chilForm;
            chilForm.TopLevel = false;
            chilForm.FormBorderStyle = FormBorderStyle.None;
            chilForm.Dock = DockStyle.Fill;
            panel2.Controls.Add(chilForm);
            panel2.Tag = chilForm;
            chilForm.BringToFront();
            chilForm.Show();
            panel1.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
            openChildForm(f3);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
            openChildForm(f4);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            f5.Show();
            openChildForm(f5);
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.Show();
            openChildForm(f6);
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form14 f14 = new Form14();
            f14.Show();
            openChildForm(f14);
        }
    }
}
