﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }
        
        SqlCommand com;
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");

        private void Form7_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("update Login set Password ='"+textBox3.Text+ "',Catagory='"+ comboBox1.Text+"' where UserName='" + textBox1.Text+"'",con);
                com.ExecuteNonQuery();
                MessageBox.Show("Password has changed successfully");
                textBox1.Text = "";
                comboBox1.Text = "";
                textBox3.Text = "";
                textBox1.Focus();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
