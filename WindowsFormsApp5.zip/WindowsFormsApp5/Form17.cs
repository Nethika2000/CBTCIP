﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp5
{
    public partial class Form17 : Form
    {
        public Form17()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");

        private void LoadData()
        {
            using (SqlCommand com = new SqlCommand("SELECT * FROM ExaminationResult", con))
            using (SqlDataAdapter da = new SqlDataAdapter(com))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form17_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                List<string> subjects = new List<string> { "Math", "Science", "History" };
                List<int> marks = new List<int> { 85, 92, 78 };
                List<string> grades = new List<string> { "A", "O", "A+" };

                for (int i = 0; i < subjects.Count; i++)
                {
                    using (SqlCommand com = new SqlCommand(
                        "INSERT INTO ExaminationResult (StudentID, StudentName, Department, Semmester, SubjectName, Mark, Grade) VALUES (@StudentID, @StudentName, @Department, @Semmester, @SubjectName, @Mark, @Grade)", con))
                    {
                        com.Parameters.AddWithValue("@StudentID", textBox1.Text);
                        com.Parameters.AddWithValue("@StudentName", textBox2.Text);
                        com.Parameters.AddWithValue("@Department", comboBox1.Text);
                        com.Parameters.AddWithValue("@Semmester", comboBox2.Text);
                        com.Parameters.AddWithValue("@SubjectName", subjects[i]);
                        com.Parameters.AddWithValue("@Mark", marks[i]);
                        com.Parameters.AddWithValue("@Grade", grades[i]);
                        //com.Parameters.AddWithValue("@ExamDate", DateTime.Now);

                        com.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Data saved successfully");
                LoadData();

                //ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }
    }
}
