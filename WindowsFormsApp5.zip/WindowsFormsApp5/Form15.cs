﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Xamarin.Forms;

namespace WindowsFormsApp5
{
    public partial class Form15 : Form
    {
        public Form15()
        {
            InitializeComponent();
        }
        SqlDataReader dr;
        SqlCommand com;
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");


        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void Form15_Load(object sender, EventArgs e)
        {
            textBox1.Text = Form1.SetValueForText1;
            try
            {
                con.Open();
                com = new SqlCommand("Select * from ExaminationResult where StudentID='"+textBox1.Text+"'", con);
                dr = com.ExecuteReader();
                dr.Read();
                label12.Text = dr.GetString(4);
                label13.Text = dr.GetValue(5)+"";
                label14.Text = dr.GetString(6);
                label6.Text = dr.GetString(2); 
                label8.Text = dr.GetString(3);
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();

        }
    }
}
