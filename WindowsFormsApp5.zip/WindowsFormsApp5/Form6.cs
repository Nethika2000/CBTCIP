﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp5
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        SqlDataReader dr;
        SqlCommand com;
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");
     
        private void Form6_Load(object sender, EventArgs e)
        {
            load_data();
        }
         private void load_data()
         {
            com = new SqlCommand("select * from ExaminationResult ", con);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = com;
            DataTable dt = new DataTable();
            dt.Clear();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
         }

        //insertion
        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("insert into ExaminationResult values('" + textBox1.Text + "','" + textBox2.Text + "','" + comboBox1.Text + "','" + comboBox2.Text + "','" + comboBox3.Text + "'," + int.Parse(textBox3.Text) + ",'" + textBox5.Text + "')", con);
                com.ExecuteNonQuery();
                MessageBox.Show("Data saved successfully");
                load_data();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox5.Text = "";
                comboBox1.Text = "";
                comboBox2.Text = "";
                comboBox3.Text = "";
                textBox1.Focus();                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        //Search
        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                textBox2.Text = "";
                textBox3.Text = "";
                textBox5.Text = "";
                comboBox1.Text = "";
                comboBox2.Text = "";
                comboBox3.Text = "";
                con.Open();
                com = new SqlCommand("Select * from ExaminationResult where StudentID='" + textBox1.Text + "' ", con);
                dr = com.ExecuteReader();
                dr.Read();
                textBox2.Text = dr.GetString(1);
                textBox3.Text = dr.GetValue(5) + "";
                textBox5.Text = dr.GetString(6);
                comboBox1.Text = dr.GetString(2);
                comboBox2.Text = dr.GetString(3);
                comboBox3.Text = dr.GetString(4);
                textBox1.Focus();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        //Update
        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("update ExaminationResult set StudentName='" + textBox2.Text + "',Department='" + comboBox1.Text + "',Semmester='" + comboBox2.Text + "',SubjectName='" + comboBox3.Text + "',Mark='"+ textBox3.Text + "',Grade='" + textBox5.Text + "' where StudentID='" + textBox1.Text + "' ", con);
                com.ExecuteNonQuery();
                MessageBox.Show("Data has Updated successfully");
                load_data();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox5.Text = "";
                comboBox1.Text = "";
                comboBox2.Text = "";
                comboBox3.Text = "";
                textBox1.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        //Delete
        private void button4_Click_1(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("delete from ExaminationResult where StudentID = '" + textBox1.Text + "' ", con);
                com.ExecuteNonQuery();
                load_data();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox5.Text = "";
                comboBox1.Text = "";
                comboBox2.Text = "";
                comboBox3.Text = "";
                textBox1.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        //Grade system
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (int.Parse(textBox3.Text) >= 91 && int.Parse(textBox3.Text) <= 100)
            {
                textBox5.Text = "O";
            }
            else if (int.Parse(textBox3.Text) >= 81 && int.Parse(textBox3.Text) <= 90)
            {
                textBox5.Text = "A+";
            }
            else if (int.Parse(textBox3.Text) >= 71 && int.Parse(textBox3.Text) <= 80)
            {
                textBox5.Text = "A";
            }
            else if (int.Parse(textBox3.Text) >= 61 && int.Parse(textBox3.Text) <= 70)
            {
                textBox5.Text = "B+";
            }
            else if (int.Parse(textBox3.Text) >= 51 && int.Parse(textBox3.Text) <= 60)
            {
                textBox5.Text = "B";
            }
            else if (int.Parse(textBox3.Text) >= 41 && int.Parse(textBox3.Text) <= 50)
            {
                textBox5.Text = "C";
            }
            else if (int.Parse(textBox3.Text) >= 35 && int.Parse(textBox3.Text) <= 40)
            {
                textBox5.Text = "D";
            }
            else if (int.Parse(textBox3.Text) >= 0 && int.Parse(textBox3.Text) <= 34)
            {
                textBox5.Text = "Fail";
            }
        }
    }
}
