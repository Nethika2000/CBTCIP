﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace WindowsFormsApp5
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        
        SqlDataReader dr;
        SqlCommand com;
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");
        
        
        string gender;
        String mothertongue;
        //Upload
        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "png files(*.png)|*.png|jpg files(*.jpg)|*.jpg|All files(*.*)|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);   
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            load_data();
        }
        // to load the data in gridview control
         private void load_data()
         {
            com=new SqlCommand("SELECT * FROM Bio_data", con);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = com;
            DataTable dt = new DataTable();
            dt.Clear();
            da.Fill(dt);
            dataGridView1.RowTemplate.Height = 75;
            dataGridView1.DataSource= dt;
            DataGridViewImageColumn pic1 = new DataGridViewImageColumn();
            pic1 = (DataGridViewImageColumn)dataGridView1.Columns[15];
            pic1.ImageLayout=DataGridViewImageCellLayout.Stretch;

         }       

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }
        //Insert

        private void button2_Click(object sender, EventArgs e)
        {
            MemoryStream ms= new MemoryStream();
            pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);

            try
            {
                con.Open();
                com = new SqlCommand("insert into Bio_data values('" + textBox1.Text + "','" +  textBox2.Text + "','" + dateTimePicker1.Text + "','" + gender + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "','" + textBox11.Text + "','" + textBox10.Text + "','" + textBox12.Text + "','" + textBox13.Text + "','" + mothertongue + "',@images)", con);
                com.Parameters.Add(new SqlParameter("@images", ms.ToArray()));
                com.ExecuteNonQuery();
                MessageBox.Show("Data inserted successfully");
                textBox1.Focus();
                textBox1.Text = "";
                textBox2.Text = "";
                dateTimePicker1.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";
                textBox12.Text = "";
                textBox13.Text = "";
                radioButton1.Checked = false;
                radioButton2.Checked = false;
                radioButton3.Checked = false;
                radioButton4.Checked = false;
                radioButton5.Checked = false;
                dateTimePicker1.Text = "";
                pictureBox1.Image = null; 
                load_data();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            mothertongue = "Tamil";
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            mothertongue = "Malayalam";
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            mothertongue = "Hindi";
        }

        //delete
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("delete from Bio_data where StudentID=" + textBox1.Text+" ",con);
                com.ExecuteNonQuery();
                MessageBox.Show("Data has deleted Sucessfully");
                textBox1.Focus();
                textBox1.Text = "";
                textBox2.Text = "";
                dateTimePicker1.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";
                textBox12.Text = "";
                textBox13.Text = "";
                radioButton1.Checked = false;
                radioButton2.Checked = false;
                radioButton3.Checked = false;
                radioButton4.Checked = false;
                radioButton5.Checked = false;
                dateTimePicker1.Text = "";
                pictureBox1.Image = null;
                load_data();
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message);    
            }
            con.Close() ;
                        
        }
        //StatusBar date and time
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.CustomFormat = "dd/MM/yyyy";
        }
        //Search
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com=new SqlCommand("Select * from Bio_data  where StudentID='" + textBox1.Text+"'",con);
                dr=com.ExecuteReader();
                dr.Read();
                textBox2.Text = dr.GetString(1);
                dateTimePicker1.Text=dr.GetString(2);            
                textBox4.Text = dr.GetString(4);
                textBox5.Text=dr.GetString(5);
                textBox6 .Text = dr.GetString(6);
                textBox7 .Text = dr.GetString(7);
                textBox8 .Text = dr.GetString(8);
                textBox9 .Text = dr.GetString(9);
                textBox10 .Text = dr.GetString(11);
                textBox11 .Text = dr.GetString(10);
                textBox12 .Text = dr.GetString(12);
                textBox13 .Text = dr.GetString(13);
                string gender = dr.GetString(3); // Change index if necessary
                                                 // Set the gender radio buttons based on the retrieved value
                switch (gender)
                {
                    case "Male":
                        radioButton1.Checked = true;
                        break;
                    case "Female":
                        radioButton2.Checked = true;
                        break;                    
                    default:
                        radioButton1.Checked = false;
                        radioButton2.Checked = false;
                        break;
                }
                // Assuming mother tongue value is stored as an integer or string at column index 5
                string mothertongue = dr.GetString(14); // Change index if necessary
                                                       // Set the mother tongue radio buttons based on the retrieved value
                switch (mothertongue)
                {
                    case "Tamil":
                        radioButton3.Checked = true;
                        break;
                    case "Malayalam":
                        radioButton4.Checked = true;
                        break;
                    case "Hindi":
                        radioButton5.Checked = true;
                        break;            
                    default:
                        radioButton3.Checked = false;
                        radioButton2.Checked = false;
                        radioButton5.Checked = false;                        
                        break;
                }
                if (!dr.IsDBNull(15)) // Assuming Image1 is at index 15
                {
                    byte[] imageData = (byte[])dr["Image1"];
                    MemoryStream ms = new MemoryStream(imageData);
                    pictureBox1.Image = Image.FromStream(ms);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            con.Close() ;
        }
        //Update
        private void button4_Click(object sender, EventArgs e)
        {
            MemoryStream ms = new MemoryStream();
            pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
            try
            {
                con.Open();
                com = new SqlCommand("Update Bio_data set StudentName='" + textBox2.Text + "',  DOB= '" + dateTimePicker1.Text + "',Sex='" + gender + "', Mother_Name='" + textBox4.Text + "', MOccupation='" + textBox5.Text + "', Father_Name='" + textBox6.Text + "', FOccupation= '" + textBox7.Text + "', Address='" + textBox8.Text + "', EmailID='" + textBox9.Text + "', Phone_Number='" +textBox11.Text + "', Nationality='" + textBox10.Text + "', Religion='" + textBox12.Text + "', Caste='" + textBox13.Text + "', Mother_tongue='" + mothertongue + "', Image1= @images where StudentID='" + textBox1.Text + "' ", con);
                com.Parameters.Add(new SqlParameter("@images", ms.ToArray()));
                com.ExecuteNonQuery();
                MessageBox.Show("Data has updated successfully");
                textBox1.Text = "";
                textBox2.Text = "";
                dateTimePicker1.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";
                textBox12.Text = "";
                textBox13.Text = "";
                radioButton1.Checked = false;
                radioButton2.Checked = false;
                radioButton3.Checked = false;
                radioButton4.Checked = false;
                radioButton5.Checked = false;
                dateTimePicker1.Text = "";
                pictureBox1.Image = null;
                textBox1.Focus();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
    }
}
