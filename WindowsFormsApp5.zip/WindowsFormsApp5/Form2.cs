﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            customizeDesign();
            
        }
        private void customizeDesign()
        {
            panel7.Visible = false;
            panel8.Visible = false;
        }
        private void hidemenu()
        {
            if (panel7.Visible == true)
            {
                panel7.Visible = false;
            }
            if (panel8.Visible == true)
            {
                panel8.Visible = false;
            }
        }
        private void showSubmenu(Panel Submenu)
        {
            if (Submenu.Visible == false)
            {
                hidemenu();
                Submenu.Visible = true;
            }
            else
            {
                Submenu.Visible = false;
            }

        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }         
        private void button9_Click(object sender, EventArgs e)
        {
            if(activeForm!=null)
            {
                activeForm.Close();
            }
            panel4.Controls.Add(panel2);

        }

        private Form activeForm = null;
        private void openChildForm(Form chilForm)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = chilForm;
            chilForm.TopLevel = false;
            chilForm.FormBorderStyle = FormBorderStyle.None;
            chilForm.Dock = DockStyle.Fill;
            panel2.Controls.Add(chilForm);
            panel2.Tag = chilForm;
            chilForm.BringToFront();
            chilForm.Show();
            panel9.Hide();
            panel4.Hide();
            panel5.Hide();
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text=DateTime.Now.ToShortDateString();
            toolStripStatusLabel2.Text=DateTime.Now.ToLongTimeString();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            showSubmenu(panel8);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            showSubmenu(panel7);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Form3());
            hidemenu();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Form4());
            hidemenu();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Form5());
            hidemenu();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Form6());
            hidemenu();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            openChildForm(new Form7());
            hidemenu();
        }

        

        private void button7_Click(object sender, EventArgs e)
        {
            openChildForm(new Form13());
            hidemenu();
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            openChildForm(new Form16());
            hidemenu();
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripStatusLabel2_Click(object sender, EventArgs e)
        {

        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }
    }
}
