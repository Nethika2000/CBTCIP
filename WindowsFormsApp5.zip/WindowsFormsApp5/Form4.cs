﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");
        SqlCommand com;
        SqlDataReader dr;

        
        private void Form4_Load(object sender, EventArgs e)
        {
            load_data();
        }

        private void load_data()
        {
            com= new SqlCommand("select * from FeesAccount", con);
            SqlDataAdapter da= new SqlDataAdapter(); 
            da.SelectCommand = com;
            DataTable dt = new DataTable();
            dt.Clear();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        //inserting
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("insert into FeesAccount values('"+textBox1.Text+"','"+textBox2.Text+"','"+textBox3.Text+"','"+textBox4.Text+"','"+textBox5.Text+"')",con);
                com.ExecuteNonQuery();
                MessageBox.Show("Data Added successfully");
                load_data();
                textBox1.Focus();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";               
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        //Deleting
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("delete from FeesAccount where StudentID='" +textBox1.Text+"'",con);
                com.ExecuteNonQuery();
                MessageBox.Show("Data has deleted Successfully");
                load_data();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox1.Focus();                
            }
            catch(Exception ex)
            {
                MessageBox.Show (ex.Message);
            }
            con.Close();
        }
        //Search
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                con.Open();
                com = new SqlCommand("select * from FeesAccount where StudentID='" +textBox1.Text+"' ",con);
                dr = com.ExecuteReader();
                dr.Read();
                textBox2.Text = dr.GetString(1);
                textBox3.Text=dr.GetString(2);  
                textBox4.Text=dr.GetString(3);
                textBox5.Text=dr.GetString(4);
                con.Close();
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
            con.Close() ;
        }
        //Updating
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("update FeesAccount set StudentName='"+textBox2.Text+ "',Total_Amount='"+textBox3.Text+"',Paid_Amount='"+textBox4.Text+ "',Balance_Amount='"+textBox5.Text+"' where StudentID='" + textBox1.Text+"'",con);
                com.ExecuteNonQuery();
                MessageBox.Show("Data has updated successfully");
                load_data();
                
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox1.Focus();
                //textBox5.Clear();
            }
            catch(Exception ex) 
            {
                MessageBox.Show (ex.Message);
            }
            con.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            try
            {
                textBox5.Text = int.Parse(textBox3.Text) - int.Parse(textBox4.Text) + "";
            }
            catch (Exception ex) 
            {
                MessageBox.Show (ex.Message);   
            }
        }
    }
}
