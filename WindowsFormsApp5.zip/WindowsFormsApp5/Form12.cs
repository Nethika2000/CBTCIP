﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp5
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();

        }
        SqlDataReader dr;
        SqlCommand com;
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");
        //SqlDataAdapter da;
        
        private void label31_Click(object sender, EventArgs e)
        {
            try
            {
               label31.Text= int.Parse(label18.Text)+ int.Parse(label19.Text)+int.Parse(label20.Text)+int.Parse(label21.Text)+int.Parse(label22.Text)+int.Parse(label23.Text)+"";

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label24_Click(object sender, EventArgs e)
        {
            if (int.Parse(label18.Text) >= 80 && int.Parse(label18.Text) <= 100)
            {
                label24.Text = "A+";
            }
            else if(int.Parse(label18.Text) >= 70 && int.Parse(label18.Text) <= 79)
            {
                label24.Text = "A";
            }
            else if (int.Parse(label18.Text) >= 60 && int.Parse(label18.Text) <= 69)
            {
                label24.Text = "B";
            }
            else if (int.Parse(label18.Text) >= 50 && int.Parse(label18.Text) <= 59)
            {
                label24.Text = "C";
            }
            else if (int.Parse(label18.Text) >= 40 && int.Parse(label18.Text) <= 49)
            {
                label24.Text = "Fail";
            }
        }

        private void label25_Click(object sender, EventArgs e)
        {
            if (int.Parse(label19.Text) >= 80 && int.Parse(label19.Text) <= 100)
            {
                label25.Text = "A+";
            }
            else if (int.Parse(label19.Text) >= 70 && int.Parse(label19.Text) <= 79)
            {
                label25.Text = "A";
            }
            else if (int.Parse(label19.Text) >= 60 && int.Parse(label19.Text) <= 69)
            {
                label25.Text = "B";
            }
            else if (int.Parse(label19.Text) >= 50 && int.Parse(label19.Text) <= 59)
            {
                label25.Text = "C";
            }
            else if (int.Parse(label19.Text) >= 40 && int.Parse(label19.Text) <= 49)
            {
                label25.Text = "Fail";
            }
        }

        private void label26_Click(object sender, EventArgs e)
        {
            if (int.Parse(label20.Text) >= 80 && int.Parse(label20.Text) <= 100)
            {
                label26.Text = "A+";
            }
            else if (int.Parse(label20.Text) >= 80 && int.Parse(label20.Text) <= 100)
            {
                label26.Text = "A";
            }
            else if (int.Parse(label20.Text) >= 80 && int.Parse(label20.Text) <= 100)
            {
                label26.Text = "B";
            }
            else if (int.Parse(label20.Text) >= 80 && int.Parse(label20.Text) <= 100)
            {
                label26.Text = "C";
            }
            else if (int.Parse(label20.Text) >= 80 && int.Parse(label20.Text) <= 100)
            {
                label26.Text = "Fail";
            }
        }

        private void label27_Click(object sender, EventArgs e)
        {
            if (int.Parse(label21.Text) >= 80 && int.Parse(label21.Text) <= 100)
            {
                label27.Text = "A+";
            }
            else if (int.Parse(label21.Text) >= 80 && int.Parse(label21.Text) <= 100)
            {
                label27.Text = "A";
            }
            else if (int.Parse(label21.Text) >= 80 && int.Parse(label21.Text) <= 100)
            {
                label27.Text = "B";
            }
            else if (int.Parse(label21.Text) >= 80 && int.Parse(label21.Text) <= 100)
            {
                label27.Text = "C";
            }
            else if (int.Parse(label21.Text) >= 80 && int.Parse(label21.Text) <= 100)
            {
                label27.Text = "Fail";
            }
        }

        private void label28_Click(object sender, EventArgs e)
        {
            if (int.Parse(label22.Text) >= 80 && int.Parse(label22.Text) <= 100)
            {
                label28.Text = "A+";
            }
            else if (int.Parse(label22.Text) >= 80 && int.Parse(label22.Text) <= 100)
            {
                label28.Text = "A";
            }
            else if (int.Parse(label22.Text) >= 80 && int.Parse(label22.Text) <= 100)
            {
                label28.Text = "B";
            }
            else if (int.Parse(label22.Text) >= 80 && int.Parse(label22.Text) <= 100)
            {
                label28.Text = "C";
            }
            else if (int.Parse(label22.Text) >= 80 && int.Parse(label22.Text) <= 100)
            {
                label28.Text = "Fail";
            }
        }

        private void label29_Click(object sender, EventArgs e)
        {
            if (int.Parse(label23.Text) >= 80 && int.Parse(label23.Text) <= 100)
            {
                label29.Text = "A+";
            }
            else if (int.Parse(label23.Text) >= 80 && int.Parse(label23.Text) <= 100)
            {
                label29.Text = "A";
            }
            else if (int.Parse(label23.Text) >= 80 && int.Parse(label23.Text) <= 100)
            {
                label29.Text = "B";
            }
            else if (int.Parse(label23.Text) >= 80 && int.Parse(label23.Text) <= 100)
            {
                label29.Text = "C";
            }
            else if (int.Parse(label23.Text) >= 80 && int.Parse(label23.Text) <= 100)
            {
                label29.Text = "Fail";
            }
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("Select * from aExaminationResult where StudentID="+label1.Text+ " ", con);
                dr = com.ExecuteReader();
                dr.Read();
                label12.Text = dr.GetString(1);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
