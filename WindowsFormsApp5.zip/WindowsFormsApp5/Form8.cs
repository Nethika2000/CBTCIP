﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace WindowsFormsApp5
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
            customizeDesign();
            round();
        }
        private void customizeDesign()
        {
            panel7.Visible = false;
            panel8.Visible = false;
           
        }
        private void hidemenu()
        {
            if (panel7.Visible == true)
            {
                panel7.Visible = false;
            }
            if (panel8.Visible == true)
            {
                panel8.Visible = false;
            }
           
        }
        private void showSubmenu(Panel Submenu)
        {
            if (Submenu.Visible == false)
            {
                hidemenu();
                Submenu.Visible = true;
            }
            else
            {
                Submenu.Visible = false;
            }
        }       
        private void Form8_Load(object sender, EventArgs e)
        {

        }
        private Form activeForm = null;
        private void openChildForm(Form chilForm)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = chilForm;
            chilForm.TopLevel = false;
            chilForm.FormBorderStyle = FormBorderStyle.None;
            chilForm.Dock = DockStyle.Fill;
            panel2.Controls.Add(chilForm);
            panel2.Tag = chilForm;
            chilForm.BringToFront();
            chilForm.Show();
            panel6.Hide();
            panel4.Hide();
            panel5.Hide();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = DateTime.Now.ToShortDateString();
            toolStripStatusLabel2.Text = DateTime.Now.ToLongTimeString();
        }     
        private void button1_Click_1(object sender, EventArgs e)
        {
            showSubmenu(panel7);
        }
        private void button4_Click_1(object sender, EventArgs e)
        {
            showSubmenu(panel8);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Form9());
            hidemenu();
        }
        private void button3_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Form10());
            hidemenu();
        }
        private void button5_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Form11());
            hidemenu();
        }
        private void button6_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Form15());
            hidemenu();
        }
        private void button9_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void button7_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Form16());
            hidemenu();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (popupControlContainer1.Visible ==true )
            {
                popupControlContainer1.Hide();
            }
            else 
            {
                popupControlContainer1.Show();
            }
        }
        private void round()
        {
            System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
            gp.AddEllipse(0, 0, pictureBox2.Width, pictureBox2.Height);
            Region rg = new Region(gp);
            pictureBox2.Region = rg;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form7 f7= new Form7();
            f7.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form7 f7 = new Form7();
            f7.Show();
            this.Hide();

        }

        private void label2_Click(object sender, EventArgs e)
        {
           
        }
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");
        SqlCommand com;
        SqlDataReader dr;
        private void popupControlContainer1_Paint(object sender, PaintEventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("select * from Bio_data",con);
                dr = com.ExecuteReader();
                label2.Text = dr.GetString(0);
                label3.Text = dr.GetString(1);
                con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
