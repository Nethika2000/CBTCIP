﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }
        SqlDataReader dr;
        SqlCommand com;
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");
       
        private void Form11_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("Select * from ExaminationInstruction ", con);
                dr = com.ExecuteReader();
                dr.Read();
                richTextBox1.Text = dr.GetString(0);                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close() ;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
