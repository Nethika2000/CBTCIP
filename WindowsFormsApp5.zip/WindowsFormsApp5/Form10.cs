﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace WindowsFormsApp5
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }
        SqlDataReader dr;
        SqlCommand com;
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");

        private void Form10_Load(object sender, EventArgs e)
        {
            textBox1.Text = Form1.SetValueForText1;
            try
            {
                con.Open();
                com = new SqlCommand("Select * from FeesAccount where StudentID='"+textBox1.Text+"'", con);
                dr = com.ExecuteReader();
                dr.Read();
                label5.Text = dr.GetString(2);
                label6.Text = dr.GetString(3);
                label7.Text=dr.GetString(4);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
