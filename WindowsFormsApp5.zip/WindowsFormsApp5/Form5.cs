﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp5
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        SqlDataReader dr;
        SqlCommand com;
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");
        

        //Saving/insertion
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("insert into ExaminationInstruction values('" + textBox1.Text+"')",con);
                com.ExecuteNonQuery();
                MessageBox.Show("Data saved successfully");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        //on form load the data has to display
        private void Form5_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("Select * from ExaminationInstruction", con);
                dr = com.ExecuteReader();
                dr.Read();
                textBox1.Text = dr.GetString(0);                
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message);    
            }
            con.Close();
        }
        
        //Update
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("update ExaminationInstruction set instructions='" + textBox1.Text+"' ",con);
                com.ExecuteNonQuery();
                MessageBox.Show("Data updated successfully");                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
