﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp5
{
    public partial class Form14 : Form
    {
        public Form14()
        {
            InitializeComponent();
        }
        
        SqlCommand com;
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com = new SqlCommand("insert into Login values('" + textBox1.Text + "','" + textBox2.Text + "','"+comboBox1.Text+"')", con);
                com.ExecuteNonQuery();
                MessageBox.Show("New account hsa created successfully");
                textBox1.Text = "";
                textBox2.Text = "";
                textBox1.Focus();
                comboBox1.Items.Clear();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
