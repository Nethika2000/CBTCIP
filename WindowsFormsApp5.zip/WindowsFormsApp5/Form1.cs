﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS;trusted_connection=true;database=Student");

        public static string SetValueForText1 = "";

        private void button1_Click(object sender, EventArgs e)
        {
            string UserName;
            string Password;
            string Catagory;
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("select * from Login",con);

                
                if (con.State==ConnectionState.Open)
                {
                    SqlDataReader dr= com.ExecuteReader();  
                    while(dr.Read())
                    {
                        UserName = dr["UserName"].ToString(); 
                        Password = dr["Password"].ToString();
                        Catagory = dr["catagory"].ToString();
                        
                        if (UserName == textBox1.Text && Password == textBox2.Text && Catagory == "User")
                        {
                            SetValueForText1 = UserName;
                            Form8 f8 = new Form8();
                            f8.Show();
                            this.Hide();
                        }
                        if (UserName == textBox1.Text && Password == textBox2.Text && Catagory == "Admin")
                        {
                            SetValueForText1 = UserName;
                            Form2 f2 = new Form2();
                            f2.Show();
                            this.Hide(); 
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Check your username/password", "Error");
            }
            finally
            {
                con.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
