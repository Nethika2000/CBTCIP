﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace WindowsFormsApp5
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }
        SqlDataReader dr;
        SqlCommand com;
        SqlConnection con = new SqlConnection("server=LAPTOP-B0KLACMJ\\SQLEXPRESS; trusted_connection=true; database=Student");
       
        private void Form9_Load(object sender, EventArgs e)
        {
            textBox1.Text = Form1.SetValueForText1;
            try
            {
                con.Open();
                com = new SqlCommand("Select * from Bio_data where StudentID='"+ textBox1.Text  +"' ",con);
                dr = com.ExecuteReader();
               if( dr.Read())
               { 
                textBox1.Text = dr.GetString(0);
                textBox2.Text = dr.GetString(1);
                textBox15.Text = dr.GetString(2);
                textBox3.Text = dr.GetString(3);
                textBox4.Text = dr.GetString(4);                               
                textBox5.Text = dr.GetString(5);
                textBox6.Text = dr.GetString(6);
                textBox7.Text = dr.GetString(7);
                textBox8.Text = dr.GetString(8);
                textBox9.Text = dr.GetString(9);
                textBox10.Text = dr.GetString(11);
                textBox11.Text = dr.GetString(10);
                textBox12.Text = dr.GetString(12);
                textBox13.Text = dr.GetString(13);
                textBox14.Text = dr.GetString(14);
               if (!dr.IsDBNull(15)) // Assuming Image1 is at index 15
               {
                    byte[] imageData = (byte[])dr["Image1"];
                    MemoryStream ms = new MemoryStream(imageData);
                    pictureBox1.Image = Image.FromStream(ms);
               }
               }

           }
           catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com=new SqlCommand("Update Bio_data set StudentName='" + textBox2.Text + "',  DOB= '" + textBox15.Text + "',Sex='" +textBox3.Text+ "', Mother_Name='" + textBox4.Text + "', MOcupation='" + textBox5.Text + "', Father_Name='" + textBox6.Text + "', FOccupation= '" + textBox7.Text + "', Addres='" + textBox8.Text + "', EmailID='" + textBox9.Text + "', Phone_Number=" + int.Parse(textBox11.Text) + ", Nationality='" + textBox10.Text + "', Religion='" + textBox12.Text + "', Caste='" + textBox13.Text + "', Mother_tongue='" + textBox14.Text + "' Image1= @images where StudentID=" + int.Parse(textBox1.Text) + " ",con);
                com.ExecuteReader();
                MessageBox.Show("Data has saved Successfully");
                textBox1.Text = "";
                textBox2.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";
                textBox12.Text = "";
                textBox13.Text = "";
                textBox15.Text = "";
                pictureBox1.Image = null;                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }        
        private void label16_Click(object sender, EventArgs e)
        {

        }
    }
}
